local wea = worldeditadditions
local wea_c = worldeditadditions_core
local Vector3 = wea_c.Vector3

local function parse_stage2(name, parts)
	local do_airapply = false
	if parts[#parts] == "aa" or parts[#parts] == "airapply" then
		do_airapply = true
		table.remove(parts, #parts)
	end
	
	local success, vpos1, vpos2 = wea_c.parse.axes(
		parts,
		wea_c.player_dir(name)
	)
	
	if not success then return success, vpos1 end
	
	-- In this case, we aren't interested in keeping the multidirectional shape changing information insomuch as an offset to which we should shift the region's contents to.
	local offset = vpos1 + vpos2
	
	if offset == Vector3.new() then 
		return false, "Refusing to move region a distance of 0 nodes"
	end
	
	return true, offset:floor(), do_airapply
end

-- ███    ███  ██████  ██    ██ ███████
-- ████  ████ ██    ██ ██    ██ ██
-- ██ ████ ██ ██    ██ ██    ██ █████
-- ██  ██  ██ ██    ██  ██  ██  ██
-- ██      ██  ██████    ████   ███████
worldeditadditions_core.register_command("move+", { -- TODO: Make this an override
	params = "<axis:x|y|z|-x|-y|-z|?|front|back|left|right|up|down> <count> [<axis> <count> [...]] [aa|airapply]",
	description = "Moves the defined region to another location - potentially across multiple axes at once.",
	privs = { worldedit = true },
	require_pos = 2,
	parse = function(params_text)
		if not params_text then params_text = "" end
		
		local parts = wea_c.split_shell(params_text)
		
		return true, parts
	end,
	nodes_needed = function(name)
		return worldedit.volume(worldedit.pos1[name], worldedit.pos2[name])
	end,
	func = function(name, parts)
		local start_time = wea_c.get_ms_time()
		
		local success_a, copy_offset, do_airapply = parse_stage2(name, parts)
		if not success_a then return success_a, copy_offset end
		
		--- 1: Calculate the source & target regions
		-----------------------------------------------------------------------
		local source_pos1 = Vector3.clone(worldedit.pos1[name])
		local source_pos2 = Vector3.clone(worldedit.pos2[name])
		
		local target_pos1 = source_pos1 + copy_offset
		local target_pos2 = source_pos2 + copy_offset
		
		-- 2: Move the nodes
		-----------------------------------------------------------------------
		local success_b, nodes_modified = wea.move(
			source_pos1, source_pos2,
			target_pos1, target_pos2,
			do_airapply
		)
		if not success_b then return success_b, nodes_modified end
		
		-- 3: Update the defined region
		-----------------------------------------------------------------------
		wea_c.pos.set1(name, target_pos1)
		wea_c.pos.set2(name, target_pos2)
		-- worldedit.pos1[name] = target_pos1
		-- worldedit.pos2[name] = target_pos2
		-- worldedit.marker_update(name)
		
		local time_taken = wea_c.get_ms_time() - start_time
		
		
		minetest.log("action", name.." used //move+ from "..source_pos1.." - "..source_pos2.." to "..target_pos1.." - "..target_pos2..", modifying "..nodes_modified.." nodes in "..wea_c.format.human_time(time_taken))
		return true, nodes_modified.." nodes moved using offset "..copy_offset.." in "..wea_c.format.human_time(time_taken)
	end
})
