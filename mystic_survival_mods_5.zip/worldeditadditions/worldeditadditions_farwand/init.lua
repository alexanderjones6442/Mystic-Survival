worldeditadditions.farwand = {
	player_data = {}
}

local modpath = minetest.get_modpath("worldeditadditions_farwand")

dofile(modpath.."/lib/do_raycast.lua")
dofile(modpath.."/lib/farwand.lua")
dofile(modpath.."/lib/cloudwand.lua")
dofile(modpath.."/lib/multiwand.lua")
dofile(modpath.."/lib/chatcommand.lua")
dofile(modpath.."/lib/settings.lua")
