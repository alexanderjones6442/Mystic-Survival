minetest.register_tool("admintool:admin_tool", {
	description = ("Admin Multitool"),
	inventory_image = "admin_multitool.png",
	tool_capabilities = {
		full_punch_interval = 0,
		max_drop_level = 100,
		groupcaps = {
			cracky={times=[1]=0.000001, [2]=0.0000000001, [3]=0.000000000000001}, uses=0, maxlevel=4},
			choppy={times=[1]=0.000001, [2]=0.0000000001, [3]=0.000000000000001}, uses=0, maxlevel=4},
			snappy={times=[1]=0.000001, [2]=0.0000000001, [3]=0.000000000000001}, uses=0, maxlevel=4},
			crumbly={times=[1]=0.000001, [2]=0.0000000001, [3]=0.000000000000001}, uses=0, maxlevel=4},
	},
	damage_groups = {fleshy=900},
	wield_scale = {x = 2, y = 2, z = 1},
	range = 500,
	groups = {sword = 1, pickaxe = 1, axe = 1, shovel = 1, not_in_creative_inventory = 1},
})