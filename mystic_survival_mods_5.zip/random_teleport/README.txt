Random Teleport
===============

Random Teleport ("/rtp") allows a user to teleport to a random location in Minetest.
This mod is primarily intended for use on multiplayer servers.
Players can use the command to teleport away from the spawn area and find a place to build.

Version: 1.0.2
License: GNU Affero General Public License version 3 (AGPLv3)
Dependencies: none

Report bugs or request help on the forum topic or here https://github.com/Droog71/random_teleport/issues

Installation
------------

Unzip the archive, rename the folder to random_teleport and
place it in minetest/mods/

(  GNU/Linux: If you use a system-wide installation place
	it in ~/.minetest/mods/.  )

(  If you only want this to be used in a single world, place
	the folder in worldmods/ in your worlddirectory.  )

For further information or help see:
http://wiki.minetest.com/wiki/Installing_Mods