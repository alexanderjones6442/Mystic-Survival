-- Ore and Block
minetest.register_node("ravinite:ravinite_ore", {
	description = ("Ravinite Ore"),
	tiles = {"nether_rack.png^ravinite_ravinite_ore.png"},
	is_ground_content = false,
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_stone_defaults(),
	drop = "ravinite:ravinite_gem",
})

minetest.register_node("ravinite:ravinite_ore_deep", {
	description = ("Deep Ravinite Ore"),
	tiles = {"nether_rack_deep.png^ravinite_ravinite_ore.png"},
	is_ground_content = false,
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_stone_defaults(),
	drop = "ravinite:ravinite_gem",
})

minetest.register_node("ravinite:ravinite_block", {
	description = ("Ravinite Block"),
	tiles = {"ravinite_ravinite_block.png"},
	groups = {cracky = 1, level = 3},
	sounds = default.node_sound_glass_defaults(),
})

-- Tools
minetest.register_tool("ravinite:ravinite_sword", {
	description = ("Ravinite Sword"),
	inventory_image = "ravinite_ravinite_sword.png",
	tool_capabilities = {
		full_punch_interval = 0.4,
		max_drop_level = 1,
		groupcaps = {
			snappy={times={[1]=0.01, [2]=0.005, [3]=0.001}, uses=5000, maxlevel=3},
		},
		damage_groups = {fleshy=85},
	},
	sounds = {breaks = "default_tool_breaks"},
	groups = {sword = 1},
})

minetest.register_tool("ravinite:ravinite_pickaxe", {
	description = ("Ravinite Pickaxe"),
	inventory_image = "ravinite_ravinite_pickaxe.png",
	tool_capabilities = {
		full_punch_interval = 0.6,
		max_drop_level = 1,
		groupcaps = {
			cracky={times={[1]=0.01, [2]=0.05, [3]=0.001}, uses=5000, maxlevel=3},
		},
		damage_groups = {fleshy=75},
	},
	sounds = {breaks = "default_tool_breaks"},
	groups = {pickaxe = 1},
})

minetest.register_tool("ravinite:ravinite_axe", {
	description = ("Ravinite Axe"),
	inventory_image = "ravinite_ravinite_axe.png",
	tool_capabilities = {
		full_punch_interval = 0.6,
		max_drop_level = 1,
		groupcaps = {
			choppy={times={[1]=0.01, [2]=0.005, [3]=0.001}, uses=5000, maxlevel=3},
		},
		damage_groups = {fleshy=80},
	},
	sounds = {breaks = "default_tool_breaks"},
	groups = {axe = 1},
})

minetest.register_tool("ravinite:ravinite_shovel", {
	description = ("Ravinite Shovel"),
	inventory_image = "ravinite_ravinite_shovel.png",
	tool_capabilities = {
		full_punch_interval = 0.7,
		max_drop_level = 1,
		groupcaps = {
			crumbly={times={[1]=0.01, [2]=0.005, [3]=0.001}, uses=5000, maxlevel=3},
		},
		damage_groups = {fleshy=65},	
	},
	sounds = {breaks = "default_tool_breaks"},
	groups = {shovel = 1},
})

minetest.register_tool("ravinite:ravinite_longsword", {
	description = ("Ravinite Longsword"),
	inventory_image = "ravinite_ravinite_longsword.png",
	tool_capabilities = {
		full_punch_interval = 2.5,
		max_drop_level = 1,
		groupcaps = {
			snappy={times={[1]=0.01, [2]=0.005, [3]=0.001}, uses = 5000, maxlevel = 3},
		},
		damage_groups = {fleshy=95},
	},
	wield_scale = { x = 2.7, y = 2.7, z = 1 },
	range = 8,
	sounds = {breaks = "default_tool_breaks"},
	groups = {sword = 1},
})

-- Ore Mapgen
minetest.register_ore({
	ore_type       = "scatter",
	ore            = "ravinite:ravinite_ore",
	wherein        = "nether:rack",
	clust_scarcity = 100 * 100 * 100,
	clust_num_ores = 1,
	clust_size     = 1,
	y_max          = -28000,
	y_min          = -31000,
})

minetest.register_ore({
	ore_type       = "scatter",
	ore            = "ravinite:ravinite_ore_deep",
	wherein        = "nether:rack_deep",
	clust_scarcity = 100 * 100 * 100,
	clust_num_ores = 1, 
	clust_size     = 1,
	y_max          = -30000,
	y_min          = -31000,
})

-- Gem
minetest.register_craftitem("ravinite:ravinite_gem", {
	description = ("Ravinite Gem"),
	inventory_image = "ravinite_ravinite_gem.png",
})

-- Crafts
minetest.register_craft({
	output = "ravinite:ravinite_sword",
	recipe = {
		{"ravinite:ravinite_gem"},
		{"ravinite:ravinite_gem"},
		{"nether:nether_ingot"}
	},
})

minetest.register_craft({
	output = "ravinite:ravinite_pickaxe",
	recipe = {
		{"ravinite:ravinite_gem", "ravinite:ravinite_gem", "ravinite:ravinite_gem"},
		{"", "nether:nether_ingot", ""},
		{"", "nether:nether_ingot", ""}
	},
})

minetest.register_craft({
	output = "ravinite:ravinite_axe",
	recipe = {
		{"ravinite:ravinite_gem", "ravinite:ravinite_gem", ""},
		{"ravinite:ravinite_gem", "nether:nether_ingot", ""},
		{"", "nether:nether_ingot", ""}
	},
})

minetest.register_craft({
	output = "ravinite:ravinite_shovel",
	recipe = {
		{"ravinite:ravinite_gem"},
		{"nether:nether_ingot"},
		{"nether:nether_ingot"}
	},
})

minetest.register_craft({
	output = "ravinite:ravinite_longsword",
	recipe = {
		{"ravinite:ravinite_gem", "", ""},
		{"", "ravinite:ravinite_sword", ""},
		{"", "", "nether:nether_ingot"}
	},
})

minetest.register_craft({
	output = "ravinite:ravinite_block",
	recipe = {
		{"ravinite:ravinite_gem", "ravinite:ravinite_gem", "ravinite:ravinite_gem"},
		{"ravinite:ravinite_gem", "ravinite:ravinite_gem", "ravinite:ravinite_gem"},
		{"ravinite:ravinite_gem", "ravinite:ravinite_gem", "ravinite:ravinite_gem"}
	},
})

minetest.register_craft({
	output = "ravinite:ravinite_ingot 9",
	recipe = {
		{"ravinite:ravinite_block"},
	},
})