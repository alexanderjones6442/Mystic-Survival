mobs_balrog.api = {}

mobs_balrog.dofile("api", "whip_actions")
mobs_balrog.dofile("api", "balrog_behavior")
