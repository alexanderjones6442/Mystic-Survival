### Mobs Balrog
![Mobs Balrog's screenshot](screenshot.png)

**Version:** 2022-09-21

**Dependencies:** default, tnt (found in minetest_game), mobs (mobs_redo)

* © 2018-2019 Hamlet <hamlatmesehub@riseup.net> LGPL 2.1
* © 2022 fluxionary LGPL v3

* Media (Textures, Models, Sounds) license:** [CC-BY-SA 3.0 Unported]
