mobs:alias_mob("mobs:balrog", "mobs_balrog:balrog")
