minetest.register_node("msc:meselord_boss_spawn_node", {
	description = ("Mese Lord Boss Spawning Node"),
	tiles = {"default_obsidian.png^default_mese_crystal.png"},
	groups = {cracky=1, oddly_breakable_by_hand=1, level=4, not_in_creative_inventory=1},
})

minetest.register_node("msc:golem_boss_spawn_node", {
	description = ("Golem Boss Spawning Node"),
	tiles = {"default_cobble.png^default_steel_ingot.png"},
	groups = {cracky=1, level=4, not_in_creative_inventory=1},
})

minetest.register_node("msc:skullking_boss_spawn_node", {
	description = ("Skull King Boss Spawning Node"),
	tiles = {"default_stone.png^bonex.png"},
	groups = {cracky=1, level=4, not_in_creative_inventory=1},
})