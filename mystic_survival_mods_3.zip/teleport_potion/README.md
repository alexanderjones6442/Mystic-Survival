Teleport Potion

This minetest mod adds both a teleportation potion and pad to the game

https://forum.minetest.net/viewtopic.php?f=9&t=9234


Change log:

- 1.3 - Added some formspec checks and switch to enable old teleport pad texture (thanks mazes 80)
- 1.2 - New teleport pad texture, code tweaks to work with minetest 5.x
- 1.1 - Using 0.4.16+ code changes, can only teleport players now, added MineClone2 crafts and spanish translation
- 1.0 - Added changes by maybe_dragon to bookmark teleport destination before using pads and potions
- 0.9 - Update to newer functions, requires Minetest 0.4.16 to work.
- 0.8 - Teleport pads now have arrows showing direction player will face after use
- 0.7 - Can now enter descriptions for teleport pads e.g. (0,12,0,Home)
- 0.6 - Tweaked and tidied code, added map_generation_limit's
- 0.5 - Added throwable potions
- 0.4 - Code tidy and particle effects added
- 0.3 - Added Teleport Pad
- 0.2 - Bug fixes
- 0.1 - Added SFX
- 0.0 - Initial release

Lucky Blocks: 4
