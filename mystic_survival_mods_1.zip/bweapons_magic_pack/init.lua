local path = minetest.get_modpath("bweapons_magic_pack")
dofile(path .. "/weapons.lua")
