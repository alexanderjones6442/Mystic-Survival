local expensive_items = {
	{"ravinite:ravinite_gem"},
	{"ravinite:ravinite_sword"},
	{"ravinite:ravinite_longsword"},
	{"ravinite:ravinite_pickaxe"},
	{"ravinite:ravinite_axe"},
	{"ravinite:ravinite_shovel"}
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items)