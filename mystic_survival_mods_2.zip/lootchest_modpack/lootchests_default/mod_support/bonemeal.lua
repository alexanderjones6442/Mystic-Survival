local items = {
    {"bonemeal:bonemeal", 8},
    {"bonemeal:mulch", 8},
    {"bonemeal:fertiliser", 8},
    {"bonemeal:bone", 4},
    {"bonemeal:gelatin_powder", 8},
}

lootchests.add_to_loot_table("lootchests_default:basket", items)