local expensive_items = {
	{"aurenite:aurenite_lump"},
	{"aurenite:aurenite_ingot"},
	{"aurenite:aurenite_sword"},
	{"aurenite:aurenite_pickaxe"},
	{"aurenite:aurenite_axe"},
	{"aurenite:aurenite_shovel"},
	{"aurenite:aurenite_helmet"},
	{"aurenite:aurenite_chestplate"},
	{"aurenite:aurenite_leggings"},
	{"aurenite:aurenite_boots"}
}

lootchests.add_to_loot_table("lootchests_default:stone_chest", expensive_items)