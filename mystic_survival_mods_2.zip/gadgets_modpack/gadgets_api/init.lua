local path = minetest.get_modpath("gadgets_api")
dofile(path .. "/api.lua")