local path = minetest.get_modpath("gadgets_default_effects")
dofile(path .. "/effects.lua")