minetest.register_ore({
    ore_type = "scatter",
    ore = "magic_materials:stone_with_egerum",
    wherein = "default:stone",
    clust_scarcity = 14 * 14 * 14,
    clust_num_ores = 5,
    clust_size = 3,
    y_max = -128,
    y_min = -31000,
})

minetest.register_ore({
    ore_type = "scatter",
    ore = "magic_materials:stone_with_februm",
    wherein = "default:stone",
    clust_scarcity = 13 * 13 * 13,
    clust_num_ores = 6,
    clust_size = 3,
    y_max = -64,
    y_min = -31000,
})