Minetest Game mod: keys
==========================
See license.txt for license information.

Authors of source code
----------------------
Originally by celeron55, Perttu Ahola <celeron55@gmail.com> (LGPLv2.1+)
Various Minetest developers and contributors (LGPLv2.1+)

Authors of media (textures, sounds, models and schematics)
----------------------------------------------------------

Textures
--------
Gambit (CC BY-SA 3.0):
  keys_key.png
  keys_key_skeleton.png

Features
--------
This mod uses the key API as defined in game_api.txt section [Key API].
