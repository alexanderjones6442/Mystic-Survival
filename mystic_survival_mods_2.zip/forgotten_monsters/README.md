# Forgotten Monsters ( WIP )

- BY : DUCKGO
- CREDITS : TenPlus1
- LICENSE : MIT
- TEXTURE : CC-BY-4.0
- VERSION : 0.023

- depends = default, mobs , 3d_armor
- optional_depends = awards

video : https://youtu.be/g8s-dqV5W14

Forgotten Monsters, is modpack inspired by a mod called "Forbidden Island", which adds skulls, spectruns,
and bosses to your world..
These mobs are based on "Mob Monsters" from "TenPlus1"!

Monsters :
- Skull Normal
- Skull Archers
- Skull Sword
- Humgry
- Spoky  ( removed )
- Spectrum
- Bug Stone
- Growler
- Mese Lord ( Boss )
- Golem ( Boss )
- Skull King ( Boss )

" This Last Boss can only be found in dungeons from -1100 "

Items:
- Bones , " Compatible with the mod : Bonemeal  ( By : TenPlus1 )"
- Spectrum Orb ,  " Compatible with the mod : Return Mirror ( By : Wuzzy )"
- Spectrum chest ( removed , will be added to another project )
- Hungry Sheet
- Healing
- Mese Lord trophy
- Golem trophy
- Skull King trophy
- skull king crown
- Skull King's Hammer

Blocks :
- Bone Block
- Spectrum Orb Block
